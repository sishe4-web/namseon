const socket = io();
let state = null;
let localSelected = [];
let lastPhase = null;
let setupTimerHandle = null;

const $ = id => document.getElementById(id);
const screens = [...document.querySelectorAll('.screen')];
function show(screenId){screens.forEach(s=>s.classList.toggle('active',s.id===screenId)); window.scrollTo(0,0)}
function money(n){return Number(n||0).toLocaleString('ko-KR')+'원'}
function tileLabel(t){return ['1萬','2萬','3萬','4萬','5萬','6萬','7萬','8萬','9萬','1筒','2筒','3筒','4筒','5筒','6筒','7筒','8筒','9筒','1索','2索','3索','4索','5索','6索','7索','8索','9索','東','南','西','北','白','發','中'][t]}
function renderTile(t, cls='tile'){
  const d=document.createElement('div');
  d.className=cls;
  d.dataset.tile=t;
  const img=document.createElement('img');
  img.src=`/assets/tiles/${t}.png`;
  img.alt=tileLabel(t);
  img.draggable=false;
  d.appendChild(img);
  return d;
}
function toast(msg){const x=$('toast'); x.textContent=msg; x.classList.add('show'); setTimeout(()=>x.classList.remove('show'),2200)}

$('createBtn').onclick=()=>socket.emit('create_room',{nickname:$('nickname').value.trim()||'Player 1',stake:Number($('stake').value)||1000000});
$('joinBtn').onclick=()=>socket.emit('join_room',{nickname:$('nickname').value.trim()||'Player 2',code:$('joinCode').value.trim()});
$('copyRoomBtn').onclick=async()=>{await navigator.clipboard?.writeText($('bigRoomCode').textContent); toast('방 코드를 복사했습니다.')};
$('confirmHandBtn').onclick=()=>{
  if(localSelected.length!==13){toast('13장을 선택하세요.');return}
  socket.emit('confirm_hand',{tiles:localSelected});
};
$('ronBtn').onclick=()=>socket.emit('declare_ron');
$('passRonBtn').onclick=()=>socket.emit('pass_ron');
$('nextRoundBtn').onclick=()=>socket.emit('next_round');

function renderLobby(s){
  $('roomCodeLobby').textContent=s.code; $('bigRoomCode').textContent=s.code;
  $('eastName').textContent=s.me?.seat==='EAST'?s.me?.nickname:(s.opponent?.seat==='EAST'?s.opponent?.nickname:'-');
  $('westName').textContent=s.me?.seat==='WEST'?s.me?.nickname:(s.opponent?.seat==='WEST'?s.opponent?.nickname:'-');
  $('westStatus').textContent=s.opponent?'READY':'WAITING';
}
function startSetup(s){
  if (lastPhase !== 'SETUP' && !(s.me?.setupConfirmed)) localSelected=(s.me?.hand13||[]).slice();
  $('stakeSetup').textContent=money(s.stake);
  $('setupDora').innerHTML=''; $('setupDora').appendChild(renderTile(s.doraIndicator,'tile-mini'));
  $('setupDoraBig').innerHTML=''; $('setupDoraBig').appendChild(renderTile(s.doraIndicator,'tile dora-big-tile'));
  state=s;
  renderSetupWall();
  renderSelected();
  updateSetupTimer(s.setupEndsAt);
  show('setup');
}
function toggleSelection(t){
  if(state?.me?.setupConfirmed) return;
  const index=localSelected.indexOf(t);
  if(index>=0){
    localSelected.splice(index,1);
  } else {
    if(localSelected.length>=13){toast('13장까지만 선택할 수 있습니다.');return;}
    localSelected.push(t);
  }
  renderSetupWall(); renderSelected();
}
function renderSelected(){
  $('selectedCount').textContent=localSelected.length;
  const box=$('selectedHand'); box.innerHTML='';
  localSelected.forEach((t,index)=>{
    const el=renderTile(t,'tile selected chosen-clickable');
    el.title='클릭하면 패산으로 돌아갑니다';
    el.setAttribute('aria-label',`${tileLabel(t)} 선택됨. 클릭하면 패산으로 돌아갑니다.`);
    el.onclick=()=>{
      if(state?.me?.setupConfirmed) return;
      localSelected.splice(index,1);
      renderSelected();
      toast(`${tileLabel(t)} 패를 패산으로 돌렸습니다.`);
      renderSetupWall();
    };
    box.appendChild(el);
  });

  const counts=Array(34).fill(0); localSelected.forEach(t=>counts[t]++);
  const waits=[];
  if(localSelected.length===13){
    for(let t=0;t<34;t++){
      if(counts[t]>=4)continue;
      counts[t]++; if(isAgariLocal(counts))waits.push(t); counts[t]--;
    }
  }
  const waitBox=$('waitTiles'); waitBox.innerHTML='';
  if(localSelected.length===13 && waits.length){
    waits.forEach(t=>{
      const el=renderTile(t,'tile wait-tile');
      el.title=`${tileLabel(t)} 대기`;
      waitBox.appendChild(el);
    });
  } else {
    const msg=document.createElement('span');
    msg.className='waits-empty';
    msg.textContent=localSelected.length===13?'현재 텐파이가 아닙니다.':'13장을 모두 선택하면 대기패를 보여줍니다.';
    waitBox.appendChild(msg);
  }
  const chip=$('tenpaiStatus'); chip.className='status-chip '+(waits.length?'good':'bad'); chip.textContent=localSelected.length===13?(waits.length?'텐파이':'노텐'):'판정 전';
}
function renderSetupWall(){
  const wall=state?.me?.private34Tiles||[]; const container=$('privateWall'); if(!container)return;
  container.innerHTML='';
  const chosenOccurrences={}; for(const t of localSelected) chosenOccurrences[t]=(chosenOccurrences[t]||0)+1;
  const renderedOccurrences={};
  wall.forEach(t=>{
    renderedOccurrences[t]=(renderedOccurrences[t]||0)+1;
    const el=renderTile(t);
    if(renderedOccurrences[t] <= (chosenOccurrences[t]||0)) el.classList.add('selected');
    el.onclick=()=>toggleSelection(t);
    container.appendChild(el);
  });
}
function isChiitoiLocal(c){return c.filter(n=>n===2).length===7&&c.every(n=>n===0||n===2)}
function isKokushiLocal(c){const yaos=[0,8,9,17,18,26,27,28,29,30,31,32,33];let p=false;for(const t of yaos){if(!c[t])return false;if(c[t]>=2)p=true}for(let t=0;t<34;t++)if(!yaos.includes(t)&&c[t])return false;return p}
function isStdLocal(c){const a=c.slice();function rec(pos,pair,groups){while(pos<34&&!a[pos])pos++;if(pos===34)return pair&&groups===4;if(!pair&&a[pos]>=2){a[pos]-=2;if(rec(pos,true,groups))return true;a[pos]+=2}if(a[pos]>=3){a[pos]-=3;if(rec(pos,pair,groups+1))return true;a[pos]+=3}if(pos<27&&pos%9<=6&&a[pos+1]&&a[pos+2]){a[pos]--;a[pos+1]--;a[pos+2]--;if(rec(pos,pair,groups+1))return true;a[pos]++;a[pos+1]++;a[pos+2]++}return false}return rec(0,false,0)}
function isAgariLocal(c){return isKokushiLocal(c)||isChiitoiLocal(c)||isStdLocal(c)}
function updateSetupTimer(end){
  clearInterval(setupTimerHandle);
  const total=180000;
  const tick=()=>{
    const ms=Math.max(0,end-Date.now());
    const sec=Math.ceil(ms/1000);
    $('setupTimer').textContent=`${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;
    const progress=Math.max(0,Math.min(1,ms/total));
    const hg=$('hourglass');
    if(hg){
      hg.style.setProperty('--top-sand',`${(progress*72).toFixed(2)}%`);
      hg.style.setProperty('--bottom-sand',`${((1-progress)*72).toFixed(2)}%`);
      hg.classList.toggle('urgent',ms>0 && ms<=30000);
      hg.classList.toggle('empty',ms<=0);
    }
    if(ms<=0)clearInterval(setupTimerHandle);
  };
  tick(); setupTimerHandle=setInterval(tick,250);
}

function renderGame(s){
  show('game'); $('roomInGame').textContent='ROOM '+s.code; $('stakeGame').textContent=money(s.stake); $('mySeat').textContent=s.me.seat==='EAST'?'東':'西'; $('opponentName').textContent=s.opponent?.nickname||'상대'; $('opponentSeat').textContent=s.opponent?.seat==='EAST'?'東':'西'; $('opponentCount').textContent=`${s.opponent?.discardCount||0}/17`; $('doraGame').innerHTML=''; $('doraGame').appendChild(renderTile(s.doraIndicator,'tile dora-game-tile'));
  $('opponentRiichi').textContent=s.opponent?.isRiichi?'RIICHI':'-'; $('myRiichi').textContent=s.me.isRiichi?'RIICHI':'NO RIICHI'; $('myTenpai').textContent=s.me.isTenpai?'TENPAI':'NOTEN'; $('myFuriten').textContent=s.me.furiten?'FURITEN':''; $('discardProgress').textContent=`${s.me.discardCount}/17`;
  $('turnIndicator').textContent=s.turn===s.me.seat?'MY TURN':'OPPONENT TURN';
  const od=$('opponentDiscards'); od.innerHTML=''; (s.opponent?.discardedTiles||[]).forEach(t=>od.appendChild(renderTile(t,'tile discard-tile')));
  const cand=$('candidates');cand.innerHTML='';(s.me.discardCandidates||[]).forEach(t=>{const el=renderTile(t);el.onclick=()=>{if(s.turn!==s.me.seat)return toast('상대 턴입니다.');socket.emit('discard_tile',{tile:t})};cand.appendChild(el)});
  const hand=$('myHand');hand.innerHTML='';(s.me.hand13||[]).forEach(t=>hand.appendChild(renderTile(t,'tile')));
  const ld=$('lastDiscard'); if(s.lastDiscard!=null){ld.classList.remove('hidden');ld.innerHTML='';ld.appendChild(renderTile(s.lastDiscard,'tile last-discard-tile'));} else ld.classList.add('hidden');
  $('candidateCount').textContent=s.me.discardCandidates?.length??0;
  const ron=$('ronBtn');ron.disabled=!s.canRon;ron.title=s.ronReason||'';
}

function renderResult(s){
  show('result');
  const r=s.result;
  const card=$('resultCard'); card.className='result-card panel';
  const fx=$('resultFx'); fx.innerHTML='';
  const headline=$('resultHeadline'); headline.innerHTML='';
  if(r?.type==='RON'){
    const won=r.winner===s.me.seat;
    card.classList.add(won?'result-win':'result-lose');
    $('resultTitle').textContent=won?'VICTORY':'DEFEAT';
    $('resultMain').textContent=r.classification;
    headline.innerHTML=`<strong>${won?'화료 성공':'화료 당함'}</strong><span>${r.winner===s.me.seat?'내가':'상대가'} ${tileLabel(r.tile)}로 론했습니다.</span>`;
    $('resultDetail').innerHTML=`<div class="score-summary"><b>${r.han}판 ${r.fu? r.fu+'부':''}</b><span>기본 ${r.baseHan}판 · 도라 ${r.dora} · 우라도라 ${r.ura}</span></div>`;
    $('moneyFlow').innerHTML=`<div class="money-card ${won?'gain':'loss'}"><span>${won?'내 수익':'내 손실'}</span><strong>${won?'+':'-'}${money(r.payment)}</strong></div><div class="money-arrow">→</div><div class="money-card"><span>${won? '상대 손실':'상대 수익'}</span><strong>${won?'-':'+'}${money(r.payment)}</strong></div>`;
    const yl=$('yakuList');yl.innerHTML='';(r.yaku||[]).forEach(y=>{const x=document.createElement('div');x.className='yaku';x.textContent=`${y[0]} ${y[1]}판`;yl.appendChild(x)});
    for(let i=0;i<(won?28:12);i++){const p=document.createElement('i');p.className='fx-particle';p.style.setProperty('--x',`${Math.random()*100}%`);p.style.setProperty('--d',`${0.4+Math.random()*0.9}s`);p.style.setProperty('--r',`${Math.random()*360}deg`);fx.appendChild(p);}
  } else {
    card.classList.add('result-draw');
    $('resultTitle').textContent='DRAW'; $('resultMain').textContent='유국';
    headline.innerHTML='<strong>17장 타패 완료</strong><span>화료가 없어 다음 판 판돈이 2배가 됩니다.</span>';
    $('resultDetail').innerHTML=`<div class="score-summary"><b>양쪽 모두 17장 타패</b><span>각자 현재 판돈 ${money(s.stake)}를 다음 판에 다시 부담합니다.</span></div>`;
    $('moneyFlow').innerHTML=`<div class="money-card loss"><span>${s.me.nickname}</span><strong>-${money(s.stake)}</strong></div><div class="money-arrow">+2×</div><div class="money-card loss"><span>${s.opponent?.nickname||'상대'}</span><strong>-${money(s.stake)}</strong></div>`;
    $('yakuList').innerHTML=`<div class="draw-pot">다음 판 판돈 <b>${money(r?.nextStake)}</b></div>`;
  }
}

socket.on('room_created',({code})=>{show('lobby');$('roomCodeLobby').textContent=code;$('bigRoomCode').textContent=code});
socket.on('joined_room',({code})=>toast(`${code} 방에 참가했습니다.`));
socket.on('notice',msg=>toast(msg));
socket.on('dora_pool',({poolSize})=>{
  const box=$('doraPool');box.innerHTML='';for(let i=0;i<poolSize;i++){const b=document.createElement('button');b.className='dora-back';b.textContent=(i+1);b.onclick=()=>socket.emit('select_dora',{index:i});box.appendChild(b)}
});
socket.on('dora_selected',({dora})=>{ $('doraWait').classList.remove('hidden'); $('doraWait').innerHTML='도라표시패: '; $('doraWait').appendChild(renderTile(dora,'tile dora-selected-tile')); });
socket.on('state',s=>{
  const previousPhase=lastPhase;
  state=s;
  if(s.phase==='WAITING'){renderLobby(s);show('lobby');}
  else if(s.phase==='DORA_SELECT') {show('dora');$('doraRoom').textContent='ROOM '+s.code; const isEast=s.me?.seat==='EAST';$('doraWait').classList.toggle('hidden',isEast);}
  else if(s.phase==='SETUP') startSetup(s);
  else if(s.phase==='PLAYING') renderGame(s);
  else if(s.phase==='RESULT'||s.phase==='DRAW') renderResult(s);
  lastPhase=s.phase;
});
socket.on('error_message',msg=>toast(msg));
